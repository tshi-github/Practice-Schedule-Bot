// gas/bot2sheet.gs
// Discord Bot からリアクションデータを受け取ってシートに追記する

function doPost(e) {
  const data  = JSON.parse(e.postData.contents);
  const sheet = config.SHEET;

  sheet.appendRow([
    new Date(),
    data.userTag,
    data.userId,
    data.eventInfo,
    data.eventDay,
    data.eventTime,
  ]);

  // 行追加直後にカレンダー同期を即時実行
  // （シート編集トリガーはAPI書き込みに発火しないため明示的に呼ぶ）
  syncCalendarsForNewUsers();
  syncEventsToCalendars();

  return ContentService.createTextOutput(JSON.stringify({ status: 'ok' }))
    .setMimeType(ContentService.MimeType.JSON);
}
